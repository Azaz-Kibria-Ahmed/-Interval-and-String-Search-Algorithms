#include "A3.h"

int main(int argc, char *argv[])
{
    if (argc < 2)
    {
        printf("specify file in CLI\n");
        return 0;
    }

    Interval intervals[INTERVAL_COUNT];
    FILE *fp = fopen(argv[1], "r");
    int i = 0;
    for (i = 0; i < INTERVAL_COUNT; i++)
    {
        fscanf(fp, "%d %d\n", &(intervals[i].start), &(intervals[i].end));
    }
    fclose(fp);
    int maxOverlaps = 0;
    int pt;

    clock_t begin = clock();
    for (i = 0; i < INTERVAL_COUNT; i++)
    {
        // printf("%d %d\n",intervals[i].start,intervals[i].end)
        int overlaps = 0;
        for (int j = 0; j < INTERVAL_COUNT; j++)
        {
            if (intervals[i].start > intervals[j].start && intervals[i].start <= intervals[j].end)
            {
                overlaps++;
                pt = intervals[j].end;
            }
        }
        if (overlaps > maxOverlaps)
        {
            maxOverlaps = overlaps;
        }
    }
    clock_t end = clock();
    double time = (double)(end - begin) / CLOCKS_PER_SEC;
    printf("Brute force program for finding max number of intervals\n");
    printf("The maximum number of intervals: %d\n", maxOverlaps);
    printf("The intervals include point: %d\n", pt);
    printf("Time for finding the maximum number: %f seconds\n", time);
    return 0;
}