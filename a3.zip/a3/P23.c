#include "A3.h"

int main(int argc, char *argv[])
{

    if (argc < 2)
    {
        printf("specify file in CLI\n");
        return 0;
    }

    char pattern[256];
    int count = 0;
    int shifts = 0;
    FILE *fp = fopen(argv[1], "r");
    fseek(fp, 0L, SEEK_END);
    unsigned long sz = ftell(fp);
    char *str = malloc(sizeof(char) * sz);
    int i = 0;
    rewind(fp);
    while ((str[i] = fgetc(fp)) != EOF)
    {
        i++;
    }
    fclose(fp);
    str[i] = '\0';

    printf("Enter pattern\n");
    scanf("%s", pattern);
    clock_t begin = clock();
    shifts = 0;
    int len = strlen(pattern);

    int *badchar = calloc(sz, sizeof(int));

    for (i = 0; i < sz; i++)
    {
        badchar[i] = -1;
    }

    for (i = 0; i < len; i++)
    {
        badchar[(int)pattern[i]] = i;
    }

    int s = 0;
    while (s <= (sz - len))
    {
        int j = len - 1;
        while (j >= 0 && pattern[j] == str[s + j])
        {
            j--;
        }

        if (j < 0)
        {
            count++;
            s += (s + len < sz) ? len - badchar[(int)str[s + len]] : 1;
        }

        else
        {
            shifts++;
            int t = j - badchar[(int)str[s + j]];
            s += 1 > t ? 1 : t;
        }
    }

    clock_t end = clock();
    double time = (double)(end - begin) / CLOCKS_PER_SEC;
    printf("A Brute force program for string search\n");
    printf("Count: %d\n", count);
    printf("Shifts: %d\n", shifts);
    printf("Execution time = %f\n", time);

    free(str);
    return 0;
}