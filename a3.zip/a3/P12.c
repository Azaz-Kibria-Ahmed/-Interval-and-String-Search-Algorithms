#include "A3.h"

int sortInt(const void *a, const void *b)
{
    return (*(int *)a) - (*(int *)b);
}

int main(int argc, char *argv[])
{

    if (argc < 2)
    {
        printf("specify file in CLI\n");
        return 0;
    }

    int startInt[INTERVAL_COUNT];
    int endInt[INTERVAL_COUNT];

    FILE *fp = fopen(argv[1], "r");
    for (int i = 0; i < INTERVAL_COUNT; i++)
    {
        fscanf(fp, "%d %d\n", &(startInt[i]), &(endInt[i]));
    }
    fclose(fp);

    int maxOverlaps = 0;
    int pt = startInt[0];
    int overlaps = 1;
    int i = 1;
    int j = 0;

    clock_t begin = clock();
    qsort(startInt, INTERVAL_COUNT, sizeof(int), sortInt);
    qsort(endInt, INTERVAL_COUNT, sizeof(int), sortInt);

    while (i < INTERVAL_COUNT && j < INTERVAL_COUNT)
    {
        if (startInt[i] < endInt[j])
        {
            if (overlaps > maxOverlaps)
            {
                maxOverlaps = overlaps;
                pt = endInt[i];
            }
            overlaps++;
            i++;
        }
        else
        {
            overlaps--;
            j++;
        }
    }

    clock_t end = clock();
    double exec = (double)(end - begin) / CLOCKS_PER_SEC;
    printf("Presort program for finding max number of intervals\n");
    printf("The maximum number of intervals: %d\n", maxOverlaps);
    printf("The intervals include point: %d\n", pt);
    printf("Time for finding the maximum number: %f seconds\n", exec);
    return 0;
}
