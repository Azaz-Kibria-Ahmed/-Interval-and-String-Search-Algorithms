#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <limits.h>


typedef struct Interval{
    int start;
    int end;
} Interval;

#define INTERVAL_COUNT 30000


