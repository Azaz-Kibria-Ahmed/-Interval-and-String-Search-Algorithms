#include "A3.h"

int main(int argc, char *argv[])
{

    if (argc < 2)
    {
        printf("specify file in CLI\n");
        return 0;
    }
    int i, j, k;
    char pattern[256];
    int count = 0;
    int shifts = 0;
    FILE *fp = fopen(argv[1], "r");

    fseek(fp, 0L, SEEK_END);
    unsigned long sz = ftell(fp);

    char *str = malloc(sizeof(char) * sz);
    int *t = calloc(sz, sizeof(int));

    i = 0;
    rewind(fp);
    while ((str[i] = fgetc(fp)) != EOF)
    {
        i++;
    }
    fclose(fp);
    str[i] = '\0';
    int strLen = strlen(str);

    printf("Enter pattern\n");
    scanf("%s", pattern);
    int len = strlen(pattern);
    clock_t begin = clock();
    for (i = 0; i < sz; i++)
    {
        t[i] = len;
    }
    for (j = 0; j < len - 1; j++)
    {
        t[(int)pattern[j]] = len - 1 - j;
    }

    i = len - 1;
    while (i < strLen)
    {
        k = 0;
        while ((k < len) && (pattern[len - 1 - k] == str[i - k]))
        {
            k++;
        }

        count += k == len ? 1 : 0;
        shifts += k != len ? 1 : 0;
        i += t[(int)str[i]];
    }
    clock_t end = clock();
    double time = (double)(end - begin) / CLOCKS_PER_SEC;
    printf("A Horspool Algorithm program for string search\n");
    printf("Count: %d\n", count);
    printf("Shifts: %d\n", shifts);
    printf("Execution time = %f\n", time);

    free(t);
    free(str);
    return 0;
}
