Comparison Results

The Horspool Algorithm on average took 11% longer than the brute force alogorithm. 
The Horspool Algorithm on average made 82% less shifts compared to the brute force alogorithm.

Test Data:

************************************************

habits
A Brute force program for string search
Count: 1
Shifts: 3296603
Execution time = 0.015198
A Horspool Algorithm program for string search
Count: 1
Shifts: 632725
Execution time = 0.018964
Time Ratio: 1.25
Shift Ratio: 0.19


ask
A Brute force program for string search
Count: 369
Shifts: 3296603
Execution time = 0.016167
A Horspool Algorithm program for string search
Count: 369
Shifts: 1159388
Execution time = 0.021016
Time Ratio: 1.30
Shift Ratio: 0.35


networking
A Brute force program for string search
Count: 1
Shifts: 3296603
Execution time = 0.017041
A Horspool Algorithm program for string search
Count: 1
Shifts: 411389
Execution time = 0.019503
Time Ratio: 1.14
Shift Ratio: 0.12

exists
A Brute force program for string search
Count: 2
Shifts: 3296603
Execution time = 0.015906
exists
A Horspool Algorithm program for string search
Count: 2
Shifts: 633955
Execution time = 0.018438
Time Ratio: 1.16
Shift Ratio: 0.19

problem
A Brute force program for string search
Count: 8
Shifts: 3296603
Execution time = 0.015733
A Horspool Algorithm program for string search
Count: 8
Shifts: 546700
Execution time = 0.017704
Time Ratio: 1.13
Shift Ratio: 0.17


political
A Brute force program for string search
Count: 8
Shifts: 3296603
Execution time = 0.015921
A Horspool Algorithm program for string search
Count: 8
Shifts: 444818
Execution time = 0.017103
Time Ratio: 1.07
Shift Ratio: 0.13

technology
A Brute force program for string search
Count: 7
Shifts: 3296603
Execution time = 0.015399
A Horspool Algorithm program for string search
Count: 7
Shifts: 386245
Execution time = 0.014827
Time Ratio: 0.96
Shift Ratio: 0.11

notification
A Brute force program for string search
Count: 10
Shifts: 3296603
Execution time = 0.017396
A Horspool Algorithm program for string search
Count: 10
Shifts: 347844
Execution time = 0.015693
Time Ratio: 0.90
Shift Ratio: 0.11


help
A Brute force program for string search
Count: 28
Shifts: 3296603
Execution time = 0.018307
A Horspool Algorithm program for string search
Count: 28
Shifts: 894350
Execution time = 0.020459
RATIO 1:1.12
Time Ratio: 1.12
Shift Ratio: 0.27


animated
A Brute force program for string search
Count: 1
Shifts: 3296603
Execution time = 0.015840
A Horspool Algorithm program for string search
Count: 1
Shifts: 519386
Execution time = 0.017012
Time Ratio: 1.07
Shift Ratio: 0.16

************************************************
