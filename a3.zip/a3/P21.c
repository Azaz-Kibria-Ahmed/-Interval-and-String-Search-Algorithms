#include "A3.h"

int main(int argc, char *argv[])
{

    if (argc < 2)
    {
        printf("specify file in CLI\n");
        return 0;
    }
    char pattern[256];
    int count = 0;
    int shifts = 0;
    FILE *fp = fopen(argv[1], "r");
    fseek(fp, 0L, SEEK_END);
    unsigned long sz = ftell(fp);
    char *str = malloc(sizeof(char) * sz);
    int i = 0;
    rewind(fp);
    while ((str[i] = fgetc(fp)) != EOF)
    {
        i++;
    }
    fclose(fp);
    str[i] = '\0';


    printf("Enter pattern\n");
    scanf("%s", pattern);
    clock_t begin = clock();
    shifts = 0;
    int len = strlen(pattern);
    while(shifts<sz){

        if(strncmp(&(str[shifts]),pattern,len)==0){
            count++;
        }

        shifts++;
    }

    clock_t end = clock();
    double time = (double)(end - begin) / CLOCKS_PER_SEC;
    printf("A Brute force program for string search\n");
    printf("Count: %d\n", count);
    printf("Shifts: %d\n", shifts);
    printf("Execution time = %f\n", time);

    free(str);
    return 0;
}